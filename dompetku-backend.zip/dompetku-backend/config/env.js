# Konfigurasi Database
MONGO_URI=mongodb+srv://admin:bayy-826@cluster0.swfp2tc.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0

# Port server
PORT=5000

# API VIP-RESELLER
API_KEY=wYCo8ip5TcGMT6zxiPhJrrOBoHet18N83wweL
API_ID=ST03wYna
API_SIGN=f455c34e7b836e666851e5c01c0179fc